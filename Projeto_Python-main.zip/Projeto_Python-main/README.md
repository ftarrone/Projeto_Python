# Projeto Python
Repositório criado para entrega do projeto Python do curso DE06 - Professora Carolina Zambelli Kamada

# Membros:

Bianca Santos Carneiro

Fernando Tarrone Molina

Guilherme Masao Tsuyukubo

# O projeto contém:

data_clean.py - script com os tratamentos dos dados

transform.py - script com as transformações dos dados

main.py - execução principal do projeto

requirements.txt
readme
